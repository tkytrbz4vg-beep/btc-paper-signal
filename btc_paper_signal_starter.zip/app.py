import math
from datetime import datetime, timezone
from urllib.parse import quote
import numpy as np
import requests
import streamlit as st

st.set_page_config(page_title="BTC paper signals", page_icon=None)
st.title("BTC / Kalshi paper-signal prototype")
st.warning("Unvalidated research model. Not an 80–90% accurate bot. No orders or background alerts.")
st.caption("Refresh manually. Signals are hypothetical, not executable quotes or guaranteed profit.")
ticker=st.text_input("Exact Kalshi market ticker (not its URL)").strip()
threshold=st.number_input("Exact BTC settlement threshold / opening reference ($)", min_value=0.0, value=0.0)
settle=st.text_input("Outcome observation time, UTC (e.g. YYYY-MM-DDTHH:MM:SS+00:00)")
cost=st.number_input("Total fee + slippage allowance per contract ($); verify actual fees", min_value=0.0, value=0.03, step=0.01)
minimum=st.slider("Minimum model probability (not verified accuracy)",0.50,0.95,0.80,0.01)
edge=st.slider("Minimum estimated net edge ($ / contract)",0.01,0.20,0.05,0.01)
confirmed=st.checkbox("I verified: YES = BTC above this threshold at this observation time; NO = otherwise. This is NOT a range market. Coinbase is only a proxy, not necessarily the settlement index.")

def get(url, **kwargs):
    r=requests.get(url, timeout=12, headers={"User-Agent":"BTC-paper-research/1.0"}, **kwargs)
    r.raise_for_status()
    return r.json()

@st.cache_data(ttl=300)
def candles():
    return get("https://api.exchange.coinbase.com/products/BTC-USD/candles", params={"granularity":60})

if st.button("Refresh and calculate paper signal"):
    try:
        if not ticker or not confirmed or threshold<=0:
            raise ValueError("Enter ticker, threshold, time and verify the rules first.")
        end=datetime.fromisoformat(settle.replace("Z","+00:00"))
        if end.tzinfo is None:
            raise ValueError("Observation time must include a timezone.")
        now=datetime.now(timezone.utc)
        minutes=(end-now).total_seconds()/60
        if not 2<=minutes<=60:
            raise ValueError("Prototype supports 2–60 minutes until observation only.")
        market=get("https://external-api.kalshi.com/trade-api/v2/markets/"+quote(ticker,safe=""))["market"]
        st.subheader(market.get("title",ticker))
        st.write(market.get("rules_primary","No rules returned"))
        st.write(market.get("rules_secondary",""))
        if market.get("status")!="active":
            raise ValueError("Market is not active; no signal.")
        if datetime.fromisoformat(market["close_time"].replace("Z","+00:00"))<=now:
            raise ValueError("Trading has closed.")
        rows=sorted([r for r in candles() if float(r[0])+60<=now.timestamp()],key=lambda r:r[0])
        if len(rows)<120 or now.timestamp()-(float(rows[-1][0])+60)>180:
            raise ValueError("Not enough recent completed candle data.")
        times=np.array([float(r[0]) for r in rows])
        if np.any(np.diff(times[-120:])!=60):
            raise ValueError("Missing candle intervals; no signal.")
        closes=np.array([float(r[4]) for r in rows])
        returns=np.diff(np.log(closes))
        sigma=max(float(np.std(returns[-60:],ddof=1)),float(np.std(returns[-119:],ddof=1)))
        if not math.isfinite(sigma) or sigma<=0:
            raise ValueError("Invalid volatility; no signal.")
        # Latest completed close is deliberately used, with its age added to uncertainty.
        age=(now.timestamp()-(float(rows[-1][0])+60))/60
        z=math.log(float(closes[-1])/threshold)/(sigma*math.sqrt(minutes+max(0,age)))
        p=0.5*(1+math.erf(z/math.sqrt(2)))
        yes=float(market["yes_ask_dollars"])
        no=float(market["no_ask_dollars"])
        if not (0<yes<1 and 0<no<1):
            raise ValueError("Missing or invalid asks; no signal.")
        candidates=[("UP / YES",p,yes),("DOWN / NO",1-p,no)]
        side,prob,ask=max(candidates,key=lambda v:v[1]-v[2]-cost)
        net=prob-ask-cost
        signal=side if prob>=minimum and net>=edge else "WAIT / NO TRADE"
        st.subheader("Paper signal: "+signal)
        st.write({"model_probability_NOT_accuracy":round(prob,4),"ask_dollars":ask,"estimated_net_edge":round(net,4),"BTC_last_completed_close":float(closes[-1]),"minutes_until_observation":round(minutes,2),"checked_UTC":now.isoformat()})
        st.caption("Zero-log-drift Gaussian return model; no training or calibration. Jumps, index differences, averaged settlement, spreads, liquidity and changing volatility can invalidate it. Quotes may change immediately. Do not use for real-money decisions.")
    except Exception as exc:
        st.error("WAIT / DATA ERROR: "+str(exc))
