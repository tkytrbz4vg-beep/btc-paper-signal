BTC / Kalshi paper-signal prototype

This is an unvalidated research starter, not an 80–90% accurate trading system.
It makes no trades, requests no credentials, sends no background notifications,
and has not been tested against live APIs in this environment.

DEPLOY
1. Create a private GitHub repository and upload app.py and requirements.txt.
2. Deploy that repository with a Streamlit-compatible Python hosting provider.
   Select app.py as the entry point. Review hosting costs and access settings.
3. Open the hosted HTTPS app in Safari on your iPhone. Optionally add it to
   your Home Screen. The Python process runs on the host, not the iPhone.
4. Enter the exact market ticker, threshold and UTC observation time from the
   market rules. Verify that YES means above that threshold and NO otherwise.
   Click Refresh and calculate paper signal. Refresh is manual.

LOCAL COMMANDS (a computer or cloud terminal, not Safari)
pip install -r requirements.txt
streamlit run app.py

LIMITATIONS
Only simple above/below outcomes, with 2–60 minutes until observation.
No range markets. Never infer UP/DOWN from a ticker alone.
Coinbase closes are a proxy, not necessarily Kalshi's settlement benchmark.
Averaged or path-dependent settlement is NOT correctly modeled.
One-minute Gaussian, zero-log-drift returns with recent volatility are only
an illustrative baseline; estimated probabilities are NOT measured accuracy.
Quotes are snapshots; no order-book depth, executable sizing, automatic
market discovery, trade journal, out-of-sample backtest or calibration exists.
Fee/slippage allowance must be verified; the default is NOT a Kalshi fee rule.
Cached candle history may be up to five minutes old; freshness checks fail
closed when insufficiently recent. A production version needs live streaming.
HTTP failures, unsupported markets and stale data return WAIT.
Do not treat this prototype as a real-money trading recommendation.

VALIDATION BEFORE REAL MONEY
Collect timestamped signals and quotes before outcomes are known. Match each
signal to the exact settlement rules and final result. Split chronologically;
keep a completely untouched test period. Report trade count, hit rate,
confidence intervals, probability calibration, net return after actual fees
and slippage, drawdown and percentage of opportunities skipped. Never label
an 80% probability filter as 80% measured accuracy. Test execution separately
in Kalshi demo only after signal validation.
